package com.css.opdpatient.utils;

/**
 * Created by Jyoti
 * all static strings will be declared here
 */

public class StringUtils {

    //shared preference keyname
    public static String PREF_USER_NAME = "user_name";


}   //end of class StringUtils
